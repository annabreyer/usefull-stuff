/**
 * Interface ${NAME}
 */
