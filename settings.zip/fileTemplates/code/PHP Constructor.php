/**
 * 
${PARAM_DOC}
${THROWS_DOC}
*/
public function __construct(${PARAM_LIST}) {${BODY}}